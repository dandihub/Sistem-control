import { BrowserRouter, Route, Routes } from "react-router-dom";
import { SidebarProvider } from "./context/SidebarContext";
import DashboardPage from "./features/dashboard/DashboardPage";
import LoginPage from "./features/auth/LoginPage";
import { AppProvider } from "./context/AppContext";
import { AuthProvider } from "./context/AuthContext";
import AuthenticatedRoutes from "./routes/AuthenticatedRoutes";
import PrivateRoutes from "./routes/PrivateRoutes";
import { Toaster } from "react-hot-toast";

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <AppProvider>
          <SidebarProvider>
            <Toaster position="top-right" />

            <Routes>
              <Route element={<PrivateRoutes />}>
                <Route path="/" element={<DashboardPage />} />
              </Route>
              <Route element={<AuthenticatedRoutes />}>
                <Route path="/login" element={<LoginPage />} />
              </Route>
            </Routes>
          </SidebarProvider>
        </AppProvider>
      </AuthProvider>
    </BrowserRouter>
  );
}
