import { useEffect, useState } from "react";
import DashboardCards from "./components/DashboardCards";
import Navbar from "./components/Navbar";
import Sidebar from "./components/Sidebar";
import BatteryChart from "./components/BatteryChart";
import ItemChart from "./components/ItemChart";
import { useSidebarContext } from "../../context/SidebarContext";
import { useAppContext } from "../../context/AppContext";
import { getDataByRange } from "../../firebase/util";
import database from "../../firebase/database";
import { limitToLast, onValue, query, ref } from "firebase/database";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import dayjs from "dayjs";
import utc from "dayjs/plugin/utc";
dayjs.extend(utc);

export default function DashboardPage() {
  const { isSidebarOpen, setIsSidebarOpen } = useSidebarContext();
  const { setData, setRelay1, setRelay2, setRelay3, setAllData } =
    useAppContext();

  const [mode, setMode] = useState<"daily" | "monthly" | "yearly">("yearly");
  const [date, setDate] = useState(dayjs().format("YYYY-MM-DD"));
  const [month, setMonth] = useState(dayjs().format("YYYY-MM"));
  const [year, setYear] = useState(dayjs().format("YYYY"));
  const [loading, setLoading] = useState(false);

  const handleTimeFilter = async () => {
    setLoading(true);
    let start: number, end: number;

    if (mode === "daily") {
      const d = dayjs.utc(date); // ⬅️ use utc here
      start = d.startOf("day").valueOf();
      end = d.endOf("day").valueOf();
    } else if (mode === "monthly") {
      const m = dayjs.utc(month); // ⬅️ utc
      start = m.startOf("month").valueOf();
      end = m.endOf("month").valueOf();
    } else {
      const y = dayjs.utc(`${year}-01-01`); // ⬅️ utc
      start = y.startOf("year").valueOf();
      end = y.endOf("year").valueOf();
    }

    const data = await getDataByRange(start, end);
    setAllData(data);
    setLoading(false);
  };

  useEffect(() => {
    handleTimeFilter();
  }, []);

  useEffect(() => {
    const handleResize = () => {
      const isMdOrLarger = window.matchMedia("(min-width: 768px)").matches;
      if (!isSidebarOpen) {
        setIsSidebarOpen(isMdOrLarger);
      }
    };

    handleResize();
  }, []);

  useEffect(() => {
    const dataRef = query(ref(database, "sensor_data"), limitToLast(1));

    onValue(dataRef, (snapshot) => {
      snapshot.forEach((childSnapshot) => {
        const item = childSnapshot.val();
        setData({ timestamp: Number(childSnapshot.key), ...item });
      });
    });

    onValue(ref(database, "relay1"), (snapshot) => setRelay1(snapshot.val()));
    onValue(ref(database, "relay2"), (snapshot) => setRelay2(snapshot.val()));
    onValue(ref(database, "relay3"), (snapshot) => setRelay3(snapshot.val()));
  }, []);

  return (
    <div className="flex h-full">
      <Sidebar />
      <div className="w-full">
        <Navbar />
        <div className="w-full flex">
          <div className="p-4 bg-gray-200 min-h-screen w-full">
            <div className="w-full flex flex-col gap-4 lg:flex-row lg:justify-between">
              <h1 className="font-semibold text-gray-600 text-3xl mt-4">
                Dashboard
              </h1>
              <div>
                <div className="rounded-lg shadow-sm mb-6 flex flex-col md:flex-row md:items-end gap-4">
                  <div>
                    <label className="block mb-1 text-sm font-medium text-gray-700">
                      Mode Filter
                    </label>
                    <select
                      value={mode}
                      onChange={(e) => setMode(e.target.value as any)}
                      className="form-select block w-[10rem] rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring focus:ring-blue-200"
                    >
                      <option value="daily">Harian</option>
                      <option value="monthly">Bulanan</option>
                      <option value="yearly">Tahunan</option>
                    </select>
                  </div>

                  {mode === "daily" && (
                    <div>
                      <label className="block mb-1 text-sm font-medium text-gray-700">
                        Tanggal
                      </label>
                      <input
                        type="date"
                        value={date}
                        onChange={(e) => setDate(e.target.value)}
                        className="form-input block w-[10rem] rounded-md p-0 px-4 pt-[0.4rem] border-gray-300 shadow-sm"
                      />
                    </div>
                  )}

                  {mode === "monthly" && (
                    <div>
                      <label className="block mb-1 text-sm font-medium text-gray-700">
                        Bulan
                      </label>
                      <DatePicker
                        selected={new Date(month + "-01")}
                        onChange={(date: Date | null, _event) => {
                          if (date) {
                            setMonth(dayjs(date).format("YYYY-MM"));
                          }
                        }}
                        dateFormat="MMMM yyyy"
                        showMonthYearPicker
                        className="form-input block w-[10rem] rounded-md border-gray-300 shadow-sm"
                      />
                    </div>
                  )}

                  {mode === "yearly" && (
                    <div>
                      <label className="block mb-1 text-sm font-medium text-gray-700">
                        Tahun
                      </label>
                      <DatePicker
                        selected={dayjs(`${year}-01-01`).toDate()}
                        onChange={(date: Date | null, _event) => {
                          if (date) {
                            setYear(dayjs(date).format("YYYY"));
                          }
                        }}
                        showYearPicker
                        dateFormat="yyyy"
                        className="form-input block w-[10rem] rounded-md border-gray-300 shadow-sm"
                      />
                    </div>
                  )}

                  <div className="flex items-end">
                    <button
                      onClick={handleTimeFilter}
                      className="inline-flex items-center px-8 py-[0.7rem] bg-blue-600 text-white text-sm font-medium rounded-md shadow-sm hover:bg-blue-700 transition"
                    >
                      {loading ? "Loading..." : "Terapkan Filter"}
                    </button>
                  </div>
                </div>
              </div>
            </div>
            <DashboardCards />

            <BatteryChart mode={mode} />
            <ItemChart index={1} mode={mode} />
            <ItemChart index={2} mode={mode} />
            <ItemChart index={3} mode={mode} />
          </div>
        </div>
      </div>
    </div>
  );
}
