import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";
import { useAppContext } from "../../../context/AppContext";
import { ItemModel } from "../../../models/ItemModel";
import dayjs from "dayjs";
import utc from "dayjs/plugin/utc";
dayjs.extend(utc);

interface BatteryChartProps {
  mode: "daily" | "monthly" | "yearly";
}

const formatLabel = (timestamp: number, mode: BatteryChartProps["mode"]) => {
  timestamp = Number(timestamp);
  const date = dayjs.utc(timestamp).local();
  if (mode === "daily") return date.format("hh:mm A");
  if (mode === "monthly") return date.format("DD MMM");
  return date.format("MMM YYYY"); // monthly
};

const aggregateData = (data: ItemModel[], mode: BatteryChartProps["mode"]) => {
  const aggregated: Record<string, { battery1: number; battery2: number; battery3: number; count: number }> = {};

  data.forEach((item) => {
    const labelKey = formatLabel(item.timestamp, mode);
    if (!aggregated[labelKey]) {
      aggregated[labelKey] = { battery1: 0, battery2: 0, battery3: 0, count: 0 };
    }
    aggregated[labelKey].battery1 += item.battery1;
    aggregated[labelKey].battery2 += item.battery2;
    aggregated[labelKey].battery3 += item.battery3;
    aggregated[labelKey].count += 1;
  });

  return Object.entries(aggregated).map(([timestamp, values]) => ({
    timestamp,
    battery1: (values.battery1 / values.count).toFixed(2),
    battery2: (values.battery2 / values.count).toFixed(2),
    battery3: (values.battery3 / values.count).toFixed(2),
  }));
};

const BatteryChart: React.FC<BatteryChartProps> = ({ mode }) => {
  const { allData } = useAppContext();
  const aggregatedData = aggregateData(allData, mode);

  return (
    <div className="my-8 py-4 bg-white px-4 rounded-lg">
      <h1 className="font-semibold text-gray-600 text-3xl mb-6 mt-4">
        Grafik Beban
      </h1>
      <ResponsiveContainer width="100%" height={300}>
        <LineChart data={aggregatedData}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="timestamp" />
          <YAxis />
          <Tooltip />
          <Legend />
          <Line type="monotone" dataKey="battery1" stroke="#8884d8" name="Beban 1" />
          <Line type="monotone" dataKey="battery2" stroke="#82ca9d" name="Beban 2" />
          <Line type="monotone" dataKey="battery3" stroke="#ffc658" name="Beban 3" />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
};

export default BatteryChart;
