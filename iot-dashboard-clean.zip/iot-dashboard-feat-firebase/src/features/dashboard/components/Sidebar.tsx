import { Home } from "iconsax-react";
import { useSidebarContext } from "../../../context/SidebarContext";
import HamburgerMenu from "./HamburgerMenu";

export default function Sidebar() {
  const { isSidebarOpen } = useSidebarContext();

  return (
    <div
      className={`${
        isSidebarOpen ? "p-8 fixed" : "p-4 hidden"
      } sm:w-auto min-h-screen w-[70%] sm:relative sm:block bg-primary text-white z-10`}
    >
      <h1
        className={`font-semibold text-4xl text-center leading-tight ${
          !isSidebarOpen ? "hidden" : ""
        }`}
      >
        System Control
      </h1>
      <div
        className={`flex gap-3 items-center font-semibold text-xl border-t-gray-300 border-t border-b border-b-gray-300 py-4 my-6 ${
          !isSidebarOpen ? "hidden" : ""
        }`}
      >
        <Home />
        <p>Dashboard</p>
      </div>
      <HamburgerMenu />
    </div>
  );
}
