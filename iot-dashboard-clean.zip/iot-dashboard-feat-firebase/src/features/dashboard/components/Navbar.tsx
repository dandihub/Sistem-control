import { useState } from "react";
import HamburgerMenu from "./HamburgerMenu";
import { User } from "iconsax-react";
import { useNavigate } from "react-router-dom";
import { logout } from "../../../firebase/util";
import { useAuthContext } from "../../../context/AuthContext";

export default function Navbar() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const { user } = useAuthContext();
  const navigate = useNavigate();

  const toggleMenu = () => {
    setIsMenuOpen((prev) => !prev);
  };

  return (
    <nav className="w-full bg-white p-4 px-8 shadow-lg flex sm:justify-end justify-between relative">
      <div className="sm:hidden">
        <HamburgerMenu />
      </div>
      <div
        onClick={toggleMenu}
        className="flex gap-3 justify-center cursor-pointer items-center"
      >
        <p>{user?.name ?? 'User'}</p>
        <div className="w-8 h-8 rounded-full bg-primary flex justify-center items-center">
          <User variant="Bold" className="text-white" />
        </div>
      </div>

      {isMenuOpen && (
        <div className="absolute top-14 right-8 bg-white shadow-lg rounded-md w-48 p-2">
          <ul className="flex flex-col gap-2">
            <li
              onClick={async () => {
                await logout();
                navigate("/login");
              }}
              className="hover:bg-gray-100 p-2 rounded cursor-pointer"
            >
              Logout
            </li>
          </ul>
        </div>
      )}
    </nav>
  );
}
