import React from "react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";
import { useAppContext } from "../../../context/AppContext";
import { ItemModel } from "../../../models/ItemModel";
import dayjs from "dayjs";
import utc from "dayjs/plugin/utc";
dayjs.extend(utc);

interface ItemChartProps {
  index: number;
  mode: "daily" | "monthly" | "yearly";
}

const formatLabel = (timestamp: number, mode: ItemChartProps["mode"]) => {
  timestamp = Number(timestamp);
  const date = dayjs.utc(timestamp).local();
  if (mode === "daily") return date.format("hh:mm A");
  if (mode === "monthly") return date.format("DD MMM");
  return date.format("MMM YYYY"); // monthly
};

const aggregateData = (
  data: ItemModel[],
  index: number,
  mode: ItemChartProps["mode"]
) => {
  const grouped: Record<
    string,
    { battery: number; voltage: number; current: number; count: number }
  > = {};

  data.forEach((item) => {
    const key = formatLabel(item.timestamp, mode);
    if (!grouped[key]) {
      grouped[key] = { battery: 0, voltage: 0, current: 0, count: 0 };
    }

    grouped[key].battery += (item as any)[`battery${index}`];
    grouped[key].voltage += parseFloat((item as any)[`voltage${index}`]);
    grouped[key].current += parseFloat((item as any)[`current${index}`]);

    grouped[key].count += 1;
  });

  return Object.entries(grouped).map(([timestamp, values]) => ({
    timestamp,
    battery: (values.battery / values.count).toFixed(2),
    voltage: (values.voltage / values.count).toFixed(2),
    current: (values.current / values.count).toFixed(2),
  }));
};

const ItemChart: React.FC<ItemChartProps> = ({ index, mode }) => {
  const { allData } = useAppContext();
  const aggregatedData = aggregateData(allData, index, mode);

  return (
    <div className="my-8 py-4 bg-white px-4 rounded-lg">
      <h1 className="font-semibold text-gray-600 text-3xl mb-6 mt-4">
        Grafik PV {index}
      </h1>
      <ResponsiveContainer width="100%" height={300}>
        <LineChart data={aggregatedData}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="timestamp" />
          <YAxis />
          <Tooltip />
          <Legend />
          <Line
            type="monotone"
            dataKey="battery"
            stroke="#8884d8"
            name={`Kapasitas ${index}`}
          />
          <Line
            type="monotone"
            dataKey="current"
            stroke="#ffc658"
            name={`Arus ${index}`}
          />
          <Line
            type="monotone"
            dataKey="voltage"
            stroke="#82ca9d"
            name={`Tegangan ${index}`}
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
};

export default ItemChart;
