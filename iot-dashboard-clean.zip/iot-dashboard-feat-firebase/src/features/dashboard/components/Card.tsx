import { ReactNode } from "react";
import { useAuthContext } from "../../../context/AuthContext";

interface CardProps {
  title: string;
  value: string | boolean;
  color: string;
  icon?: ReactNode | null;
  onChanged?: (value: boolean) => void;
}

export default function Card({
  title,
  value,
  color,
  icon,
  onChanged,
}: CardProps) {
  const { user } = useAuthContext();
  return (
    <div
      style={{ borderColor: color }}
      className={`p-6 py-8 flex justify-between items-center gap-4 ${`border-l-[${color}]`} border-l-4 rounded-lg bg-white`}
    >
      <div className="w-full">
        <p
          style={{ color: color }}
          className={`uppercase font-medium ${
            typeof value == "boolean" ? "mt-4" : ""
          } text-${color} `}
        >
          {title}
        </p>
        <h2 className="font-medium text-2xl text-gray-600">
          {typeof value == "boolean" ? (
            <div>
              <label className="inline-flex items-center mb-5 cursor-pointer">
                <input
                  type="checkbox"
                  disabled={user?.role !== "admin"}
                  checked={value}
                  onChange={(e) => {
                    onChanged?.call(null, e.target.checked);
                  }}
                  value=""
                  className="sr-only peer"
                ></input>
                <div className="relative mt-1 w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-blue-600"></div>
              </label>
            </div>
          ) : (
            `${value}`
          )}
        </h2>
      </div>
      {icon && (
        <div className="w-12 h-12 flex items-center justify-center">{icon}</div>
      )}
    </div>
  );
}
