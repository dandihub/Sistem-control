import { BiChevronLeft, BiMenu } from "react-icons/bi";
import { useSidebarContext } from "../../../context/SidebarContext";

export default function HamburgerMenu() {
  const { isSidebarOpen, setIsSidebarOpen } = useSidebarContext();

  return (
    <div
      onClick={() => setIsSidebarOpen(!isSidebarOpen)}
      className="w-12 h-12 cursor-pointer bg-blue-500 text-white rounded-full flex items-center justify-center mx-auto"
    >
      {isSidebarOpen ? (
        <BiChevronLeft className="w-8 h-8" />
      ) : (
        <BiMenu className="w-8 h-8" />
      )}
    </div>
  );
}
