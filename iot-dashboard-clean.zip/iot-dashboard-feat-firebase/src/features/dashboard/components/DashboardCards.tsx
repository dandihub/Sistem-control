import { IoBatteryFull } from "react-icons/io5";
import Card from "./Card";
import { FaLightbulb } from "react-icons/fa6";
import { useAppContext } from "../../../context/AppContext";
import {
  changeRelay1,
  changeRelay2,
  changeRelay3,
} from "../../../firebase/util";

export default function DashboardCards() {
  const { relay1, relay2, relay3, data } = useAppContext();
  return (
    <div>
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-4">
        <Card
          title="Battery 1"
          value={`${data.battery1.toFixed(2)}%`}
          color="#1C64F2"
          icon={<IoBatteryFull className="w-8 h-8 text-gray-600" />}
        />
        <Card
          title="Sensor Arus 1"
          value={`${data.current1} A`}
          color="#009688"
        />
        <Card
          title="Sensor Tegangan 1"
          value={`${data.voltage1} V`}
          color="#AFB42B"
        />
        <Card
          title="Relay 1"
          value={relay1}
          color={relay1 ? "#4CAF50" : "#F44336"}
          icon={<FaLightbulb className="w-8 h-8 text-gray-600" />}
          onChanged={changeRelay1}
        />
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <Card
          title="Battery 2"
          value={`${data.battery2.toFixed(2)}%`}
          color="#1C64F2"
          icon={<IoBatteryFull className="w-8 h-8 text-gray-600" />}
        />
        <Card
          title="Sensor Arus 2"
          value={`${data.current2} A`}
          color="#009688"
        />
        <Card
          title="Sensor Tegangan 2"
          value={`${data.voltage2} V`}
          color="#AFB42B"
        />
        <Card
          title="Relay 2"
          value={relay2}
          color={relay2 ? "#4CAF50" : "#F44336"}
          icon={<FaLightbulb className="w-8 h-8 text-gray-600" />}
          onChanged={changeRelay2}
        />
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mt-4">
        <Card
          title="Battery 3"
          value={`${data.battery3.toFixed(2)}%`}
          color="#1C64F2"
          icon={<IoBatteryFull className="w-8 h-8 text-gray-600" />}
        />
        <Card
          title="Sensor Arus 3"
          value={`${data.current3} A`}
          color="#009688"
        />
        <Card
          title="Sensor Tegangan 3"
          value={`${data.voltage3} V`}
          color="#AFB42B"
        />
        <Card
          title="Relay 3"
          value={relay3}
          color={relay3 ? "#4CAF50" : "#F44336"}
          icon={<FaLightbulb className="w-8 h-8 text-gray-600" />}
          onChanged={changeRelay3}
        />
      </div>
    </div>
  );
}
