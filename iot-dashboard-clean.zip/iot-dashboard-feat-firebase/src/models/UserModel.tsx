export interface UserModel {
    name: string;
    email: string;
    role: string;
}

export enum Role {
    ADMIN = "admin",
    USER = "user"
}