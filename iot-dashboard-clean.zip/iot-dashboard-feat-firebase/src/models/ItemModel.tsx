export interface ItemModel {
    timestamp: number;
    battery1: number;
    battery2: number;
    battery3: number;
    current1: number;
    current2: number;
    current3: number;
    voltage1: number;
    voltage2: number;
    voltage3: number;
}
