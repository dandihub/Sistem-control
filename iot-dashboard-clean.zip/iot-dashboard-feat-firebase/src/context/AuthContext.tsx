/* eslint-disable react-refresh/only-export-components */
import { createContext, useState, useContext, ReactNode, useEffect } from "react";
import { UserModel } from "../models/UserModel";
import auth from "../firebase/auth";

type AuthContextType = {
  user: UserModel | null;
  setUser: (value: UserModel | null) => void;
  checkAuth: () => boolean;
};

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [user, setUser] = useState<UserModel | null>(null);

  useEffect(() => {
    const user = localStorage.getItem("user");
    if (user) {
      setUser(JSON.parse(user));
    }

    auth.onAuthStateChanged((user) => {
      if (user) {
        const userLocal = localStorage.getItem("user");
        setUser(JSON.parse(userLocal!));
      } else {
        setUser(null);
        localStorage.removeItem("user");
      }
    });
  }, []);


  const checkAuth = () => {
    const user = localStorage.getItem("user");
    return user !== null;
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        setUser,
        checkAuth,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuthContext = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error(
      "useAuthContext must be used within an AuthProvider"
    );
  }
  return context;
};
