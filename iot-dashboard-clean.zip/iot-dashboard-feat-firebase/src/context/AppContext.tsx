/* eslint-disable react-refresh/only-export-components */
 
import {
  createContext,
  useState,
  useContext,
  ReactNode,
} from "react";

import { ItemModel } from "../models/ItemModel";

type AppContextType = {
  relay1: boolean;
  setRelay1: (value: boolean) => void;
  relay2: boolean;
  setRelay2: (value: boolean) => void;
  relay3: boolean;
  setRelay3: (value: boolean) => void;
  data: ItemModel;
  setData: (value: ItemModel) => void;
  allData: ItemModel[];
  setAllData: (value: ItemModel[]) => void;
};

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider = ({ children }: { children: ReactNode }) => {
  const [relay1, setRelay1] = useState(false);
  const [relay2, setRelay2] = useState(false);
  const [relay3, setRelay3] = useState(false);
  const [data, setData] = useState<ItemModel>({
    timestamp: 0,
    battery1: 0,
    battery2: 0,
    battery3: 0,
    current1: 0,
    current2: 0,
    current3: 0,
    voltage1: 0,
    voltage2: 0,
    voltage3: 0,
  });
  const [allData, setAllData] = useState<ItemModel[]>([]);


  return (
    <AppContext.Provider
      value={{
        relay1,
        setRelay1,
        relay2,
        setRelay2,
        relay3,
        setRelay3,
        data,
        setData,
        allData,
        setAllData,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useAppContext = () => { 
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error("useAppContext must be used within an AppProvider");
  }
  return context;
};
