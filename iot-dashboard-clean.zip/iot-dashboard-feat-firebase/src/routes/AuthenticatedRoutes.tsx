import { Navigate, Outlet } from "react-router-dom";
import { useAuthContext } from "../context/AuthContext";

const AuthenticatedRoutes = () => {
  const { checkAuth } = useAuthContext();
  return !checkAuth() ? <Outlet /> : <Navigate to="/" />;
};
export default AuthenticatedRoutes;
