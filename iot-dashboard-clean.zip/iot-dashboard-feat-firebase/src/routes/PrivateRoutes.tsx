import { Navigate, Outlet } from "react-router-dom";
import { useAuthContext } from "../context/AuthContext";

const PrivateRoutes = () => {
  const { checkAuth } = useAuthContext();
  return checkAuth() ? (
    <>
      <Outlet />
    </>
  ) : (
    <Navigate to="/login" />
  );
};
export default PrivateRoutes;
