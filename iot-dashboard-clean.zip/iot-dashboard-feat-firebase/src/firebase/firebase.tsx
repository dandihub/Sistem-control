import { initializeApp } from "firebase/app";

const firebaseConfig = {
  apiKey: "AIzaSyD5wheikd01CmWswwP1ujBbbBODI64PGSc",
  authDomain: "iot-dashboard-4d34b.firebaseapp.com",
  databaseURL: "https://iot-dashboard-4d34b-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: "iot-dashboard-4d34b",
  storageBucket: "iot-dashboard-4d34b.firebasestorage.app",
  messagingSenderId: "528794982951",
  appId: "1:528794982951:web:04b1eaedcdf1197d6a8c02",
  measurementId: "G-N1W7KVEXZ1"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
export default app;