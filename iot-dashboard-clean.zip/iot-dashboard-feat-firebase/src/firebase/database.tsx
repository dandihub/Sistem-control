import app from "./firebase";
import { getDatabase } from "firebase/database";

const database = getDatabase(app);

export default database;
