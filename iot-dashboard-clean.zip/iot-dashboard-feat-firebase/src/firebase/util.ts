import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
} from "firebase/auth";
import { ItemModel } from "../models/ItemModel";
import auth from "./auth";
import database from "./database";
import {
  set,
  ref,
  update,
  get,
  query,
  orderByChild,
  equalTo,
  startAt,
  endAt,
  orderByKey
} from "firebase/database";
import { UserModel } from "../models/UserModel";
import { FirebaseError } from "firebase/app";

function changeRelay1(value: boolean) {
  set(ref(database, "relay1"), value);
}

function changeRelay2(value: boolean) {
  set(ref(database, "relay2"), value);
}

function changeRelay3(value: boolean) {
  set(ref(database, "relay3"), value);
}

function addData(collection: string, timeInMs: number, value:any) {
  const dataRef = ref(database, `${collection}/${timeInMs}`);
  set(dataRef, value);
}

async function addUser(name: string, email: string, password: string) {
  if (await checkIfUserExists(email)) {
    throw new Error("User already exists!");
  }
  const credential = await createUserWithEmailAndPassword(
    auth,
    email,
    password
  );
  const usersRef = ref(database, `users/${credential.user.uid}`);
  await set(usersRef, { name, email, role: "user" });
}

async function getUser(): Promise<UserModel | null> {
  if (!auth.currentUser) {
    return null;
  }
  const usersRef = ref(database, `users/${auth.currentUser.uid}`);
  const snapshot = await get(usersRef);
  if (!snapshot.exists()) {
    return null;
  }
  return snapshot.val() as UserModel;
}

async function login(email: string, password: string): Promise<UserModel | null> {
  try {
    await signInWithEmailAndPassword(auth, email, password);
    const user = await getUser();
    localStorage.setItem("user", JSON.stringify(user));
    return user;
  } catch (error) {
    if (error instanceof FirebaseError) {
      const readableMessage = mapFirebaseAuthError(error.code);
      console.error(readableMessage);
      throw readableMessage;
    } else {
      console.error("Terjadi kesalahan", error);
      throw new Error("An unexpected error occurred.");
    }
  }
}

function mapFirebaseAuthError(code: string): string {
  const errorMessages: { [key: string]: string } = {
    "auth/invalid-email": "Email tidak valid.",
    "auth/invalid-credential": "Email dan password salah.",
    "auth/user-disabled": "Akun tidak aktif.",
    "auth/user-not-found": "Akun tidak ditemukan.",
    "auth/wrong-password": "Password salah.",
    "auth/too-many-requests": "Terlalu banyak percobaan. Coba lagi nanti.",
    "auth/network-request-failed": "Silakan cek internet Anda.",
  };

  return errorMessages[code] || "Terjadi kesalahan.";
}

async function logout() {
  localStorage.removeItem("user");
  await auth.signOut();
}

async function checkIfUserExists(email: string): Promise<boolean> {
  try {
    const usersRef = ref(database, "users");
    const userQuery = query(usersRef, orderByChild("email"), equalTo(email));

    const snapshot = await get(userQuery);
    return snapshot.exists();
  } catch (error) {
    console.error("Error checking if user exists:", error);
    throw error;
  }
}

async function getData(): Promise<ItemModel[]> {
  var items: ItemModel[] = [];
  const dataRef = ref(database, "sensor_data");
  const snapshot = await get(dataRef);
  snapshot.forEach((childSnapshot) => {
    const data = childSnapshot.val();
    items.push({ timestamp: Number(childSnapshot.key), ...data });
  });
  return items;
}
/**
 * Generates and uploads dummy data to Firebase for the past 3 months, with hourly entries.
 * @param database The Firebase Realtime Database instance.
 */
function generateDummyData(): void {
  const now = Date.now(); // Current timestamp in milliseconds
  const threeMonthsAgo = now - 3 * 30 * 24 * 60 * 60 * 1000; // Approximate 3 months ago (90 days)
  const updates: Record<string, any> = {}; // Firebase batch update object

  // Generate data per hour for the last 3 months
  for (
    let timestamp = threeMonthsAgo;
    timestamp <= now;
    timestamp += 60 * 60 * 1000
  ) {
    const timeKey = timestamp.toString(); // Use timestamp as the key

    // Create an object to hold the sensor data for each timestamp
    const sensorData = {
      battery1: Math.floor(Math.random() * 100), // Battery 1: 0-99
      battery2: Math.floor(Math.random() * 100), // Battery 2
      battery3: Math.floor(Math.random() * 100), // Battery 3
      current1: (Math.random() * 10).toFixed(2), // Current 1: 0-10 (float)
      current2: (Math.random() * 10).toFixed(2), // Current 2
      current3: (Math.random() * 10).toFixed(2), // Current 3
      voltage1: (Math.random() * 5 + 3).toFixed(2), // Voltage 1: 3-8 (float)
      voltage2: (Math.random() * 5 + 3).toFixed(2), // Voltage 2
      voltage3: (Math.random() * 5 + 3).toFixed(2), // Voltage 3
    };

    // Assign the sensor data under the "timestamp" key
    updates[`data/${timeKey}`] = sensorData;
  }

  // Push all updates to Firebase in a single batch
  update(ref(database), updates)
    .then(() => {
      console.log("Dummy data for 3 months successfully generated!");
    })
    .catch((error: Error) => {
      console.error("Error generating dummy data:", error.message);
    });
}

async function getDataByTimestamp(sinceTimestamp: number) {
  const dataQuery = query(
    ref(database, "sensor_data"),
    orderByKey(),
    startAt(sinceTimestamp.toString())
  );

  const snapshot = await get(dataQuery);
  const result: any[] = [];

  snapshot.forEach((childSnapshot) => {
    result.push({
      timestamp: Number(childSnapshot.key as string),
      ...childSnapshot.val(),
    });
  });

  return result;
}

async function getDataByRange(start: number, end: number) {
  const dataQuery = query(
    ref(database, "sensor_data"),
    orderByKey(),
    startAt(start.toString()),
    endAt(end.toString())
  );

  const snapshot = await get(dataQuery);
  const result: any[] = [];

  snapshot.forEach((childSnapshot) => {
    result.push({
      timestamp: Number(childSnapshot.key as string),
      ...childSnapshot.val(),
    });
  });

  return result;
}

export {
  changeRelay1,
  changeRelay2,
  changeRelay3,
  addData,
  getData,
  generateDummyData,
  login,
  logout,
  addUser,
  getDataByTimestamp,
  getDataByRange,
};
